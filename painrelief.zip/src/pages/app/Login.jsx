import { IoIosArrowDropleftCircle } from "react-icons/io";
import { logobig, SideImg } from "../../assets/export";
import AuthInput from "../../components/app/AuthInput";
import Button from "../../components/app/Button";

const Login = () => {
  return (
    <div className="grid lg:grid-cols-2 grid-cols-1 w-full bg-[#fcfcfc]">
      {/* Left Image Panel */}
      <div className="p-4 lg:block hidden">
        <img src={SideImg} alt="Side visual" />
      </div>

      {/* Right Form Panel */}
      <div className="flex flex-col justify-center items-center h-auto">
        {/* Logo and Branding */}
        <div className="my-4 text-center">
          <div className="w-[158px] h-[158px] mx-auto">
            <img src={logobig} alt="Logo" />
          </div>
          <p className="text-[26px] mt-2 font-semibold capitalize">
            Pain Relief USA
          </p>
          <p className="text-[14px] font-[500] capitalize text-[#565656]">
            pain Relief made easy
          </p>
        </div>

        {/* Welcome Text */}
        <div className="py-4">
          <p className="text-[32px] font-[600] capitalize">Welcome Back</p>
          <p className="text-[16px] capitalize text-[#565656]">
            Please enter details to continue
          </p>
        </div>

        {/* Static Form */}
        <form>
          <div className="space-y-4 lg:w-[350px] md:w-[550px] w-[320px]">
            <AuthInput
              text={"Email address"}
              placeholder={"Enter email here"}
              type={"email"}
              id={"email"}
              name={"email"}
              maxLength={50}
              value={""}
              onChange={() => {}}
              onBlur={() => {}}
              error={""}
              touched={false}
            />
            <AuthInput
              text={"Password"}
              placeholder={"Password"}
              type={"password"}
              id={"password"}
              name={"password"}
              maxLength={50}
              value={""}
              onChange={() => {}}
              onBlur={() => {}}
              error={""}
              touched={false}
            />
          </div>

          <div className="flex my-2 justify-end lg:w-[350px] md:w-[550px] w-[320px]">
            <p className="text-[#181818] text-[12px] font-[500] pt-1 cursor-pointer">
              Forgot password?
            </p>
          </div>

          <div className="w-[350px] mt-3 mb-4">
            <Button text={"Login"} loading={false} />
          </div>
        </form>

        {/* Sign Up Prompt */}
        {/* <div className="flex items-center justify-center gap-2 my-6">
          <p className="text-center text-[16px] leading-[21.6px] text-[#181818]">
            Don’t have an account?
            <span className="bg-gradient-to-l to-[#63CFAC] from-[#29ABE2] bg-clip-text text-transparent font-medium pl-1 cursor-pointer">
              Sign Up
            </span>
          </p>
        </div> */}

        {/* Back Button */}
        {/* <button type="button" className="w-full flex justify-center items-center gap-1 cursor-pointer">
          <IoIosArrowDropleftCircle className="text-lg text-[#212121]" />
          <p className="text-[12px] uppercase font-bold leading-none tracking-wider text-[#212121]">
            Back
          </p>
        </button> */}
      </div>
    </div>
  );
};

export default Login;
