import { useState } from "react";
import { medical } from "../../assets/export";
import ChangePasswordModal from "../../components/app/ChangePasswordModal";

// Dummy provider data
const provider = {
  name: "John Alex",
  email: "john.alex@gmail.com",
  avatar: "https://i.pravatar.cc/100?img=5",
  clinicTitle: "Clinic Title",
  clinicEmail: "clinic@gmail.com",
  phone: "+000 0000 000",
  location: "Dallas, TX – 802 PainEase Plaza\nMassage Therapy Care",
  reliefCoach: "Authorized Pain Relief Coach",
  npi: "Lorem Ipsum Dolor at",
  website: "www.website.com",
  description:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...",
};

const Profile = () => {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);

  const [editData, setEditData] = useState({
    name: provider.name,
    email: provider.email,
    phone: provider.phone,
    clinicTitle: provider.clinicTitle,
    clinicEmail: provider.clinicEmail,
  });

  const handleEditClick = () => {
    setIsEditModalOpen(true);
  };

  const closeModal = () => {
    setIsEditModalOpen(false);
  };


const [passwordData, setPasswordData] = useState({
  currentPassword: "",
  newPassword: "",
  confirmPassword: "",
});

const openPasswordModal = () => setIsPasswordModalOpen(true);
const closePasswordModal = () => setIsPasswordModalOpen(false);

const handlePasswordChange = () => {
  console.log(passwordData); // send to API
  closePasswordModal();
};



  return (
    <div className="p-6 bg-white rounded-lg shadow mx-auto">
      {/* Title */}
      <h2 className="text-[24px] font-bold mb-4">Sub Admin Details</h2>

      {/* Header */}
      <div className="flex items-center justify-between bg-[#FAFAFA] rounded-lg p-6 shadow-sm mb-6">
        <div className="flex items-center">
          <img
            src={provider.avatar}
            alt="avatar"
            className="w-20 h-20 rounded-full border mr-6"
          />
          <div>
            <h3 className="text-xl font-semibold">{provider.name}</h3>
            <p className="text-gray-500">{provider.email}</p>
          </div>
        </div>
        <div className="flex gap-3">
        <button
  onClick={openPasswordModal}
  className="bg-[#63CFAC] text-white px-4 py-2 rounded-md hover:bg-[#4fb295] transition"
>
  Change Password
</button>


          <button
            onClick={handleEditClick}
            className="bg-[#29ABE2] text-white px-4 py-2 rounded-md hover:bg-[#2293c9] transition"
          >
            Edit
          </button>
        </div>
      </div>

      {/* Basic Info */}
      <div className="bg-[#FAFAFA] p-6 rounded-md text-sm space-y-6">
        <p className="text-[24px]">Sub Admin info</p>
        <span className="w-full border border-b flex"></span>
        <InfoRow label="Name of Clinic/Practice" value={provider.clinicTitle} />
        <InfoRow label="Email Address" value={provider.clinicEmail} />
        <InfoRow label="Mobile Number" value={provider.phone} />
      </div>

      {/* Edit Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-[400px] shadow-lg relative">
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 text-gray-500 hover:text-black"
            >
              &times;
            </button>

            <h2 className="text-xl font-bold mb-4">Edit Sub Admin Details</h2>

            <div className="flex items-center gap-4 mb-4">
              <img
                src={provider.avatar}
                alt="Profile"
                className="w-14 h-14 rounded-full border-2 border-[#29ABE2]"
              />
              <button className="text-[#29ABE2] text-sm font-medium underline">
                Change Profile
              </button>
            </div>

            <div className="space-y-3">
              <input
                type="text"
                value={editData.name}
                onChange={(e) =>
                  setEditData({ ...editData, name: e.target.value })
                }
                className="w-full px-4 py-2 border rounded-md"
                placeholder="Full Name"
              />
              
              <input
                type="email"
                value={editData.clinicEmail}
                readOnly
                className="w-full px-4 py-2 bg-gray-100 border rounded-md text-gray-500"
              />
              <input
                type="text"
                value={editData.phone}
                readOnly
                className="w-full px-4 py-2 bg-gray-100 border rounded-md text-gray-500"
              />
            </div>

            <button className="w-full mt-6 bg-gradient-to-r from-[#29ABE2] to-[#63CFAC] text-white py-2 rounded-md">
              Save
            </button>
          </div>
        </div>
      )}
      <ChangePasswordModal
  isOpen={isPasswordModalOpen}
  onClose={closePasswordModal}
  onSubmit={handlePasswordChange}
  formData={passwordData}
  setFormData={setPasswordData}
/>

    </div>
    
  );
};

const InfoRow = ({ label, value, multi, last }) => (
  <div className={`py-2 ${!last ? "border-b border-gray-300" : ""}`}>
    <p className="text-gray-400 mb-1">{label}</p>
    <p className={`text-black ${multi ? "whitespace-pre-line" : ""}`}>{value}</p>
  </div>
);

export default Profile;
