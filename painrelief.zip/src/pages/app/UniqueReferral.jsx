import { useState } from "react";
import { IoSearch } from 'react-icons/io5'; // Import the search icon


const staticReferrals = [
  {
    id: 1,
    referralId: "RF54154",
    referralBy: { name: "John Doe", avatar: "https://i.pravatar.cc/40?img=10" },
    referredMember: { name: "John Alex", avatar: "https://i.pravatar.cc/40?img=5" },
    email: "johnalex@mail.com",
    signUpDate: "26 Feb, 2025",
    status: "Active",
  },
  {
    id: 2,
    referralId: "RF54155",
    referralBy: { name: "Jane Smith", avatar: "https://i.pravatar.cc/40?img=11" },
    referredMember: { name: "Mary Jane", avatar: "https://i.pravatar.cc/40?img=6" },
    email: "maryjane@mail.com",
    signUpDate: "28 Feb, 2025",
    status: "Inactive",
  },
];

const UniqueReferral = () => {
  const [search, setSearch] = useState("");

  const filteredData = staticReferrals.filter(({ referredMember }) =>
    referredMember.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 bg-white rounded-lg shadow">
      {/* Header with title and filter tabs on left, search + filter button on right */}
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-8">
          <h2 className="text-[24px] font-bold">Unique Referral</h2>
          <div className="flex gap-4 text-sm font-medium">
            <span className="text-[#38BDF8] border-b-2 border-[#38BDF8] pb-1 cursor-pointer">
              User Referral
            </span>
            <span className="text-gray-400 cursor-pointer">Chiropractor Referral</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
           <div className="flex items-center border rounded px-3 py-2 w-64 shadow-sm">
      <IoSearch className="text-gray-500 mr-2" /> {/* Search Icon */}
      <input
        type="text"
        placeholder="Search"
        className="w-full border-none outline-none"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
    </div>
          <button className="p-2 rounded-full border bg-gradient-to-l from-[#29ABE2] to-[#63CFAC]">
            <svg
              className="w-5 h-5 text-white"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              viewBox="0 0 24 24"
            >
              <path d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L14 13.414V19a1 1 0 01-1.447.894l-4-2A1 1 0 018 17v-3.586L3.293 6.707A1 1 0 013 6V4z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Table header */}
      <div className="bg-[#FAFAFA] p-4 rounded-md">
        <div
          className="grid grid-cols-[40px_1fr_1.5fr_1.7fr_1.5fr_1.2fr_1fr] gap-4 px-4 py-3 rounded-md text-sm text-black"
          style={{
            background: "linear-gradient(90deg, rgba(150,210,240,1) 0%, rgba(190,230,210,1) 50%)",
          }}
        >
          <div>#</div>
          <div>Referral ID</div>
          <div>Referral By</div>
          <div>Referred Member</div>
          <div>Member Email Address</div>
          <div>Sign Up Date</div>
          <div>Status</div>
        </div>

        {/* Rows */}
        <div className="divide-y">
          {filteredData.length > 0 ? (
            filteredData.map((item, index) => (
              <div
                key={item.id}
                className="grid grid-cols-[40px_1fr_1.5fr_1.7fr_1.5fr_1.2fr_1fr] gap-4 px-4 py-6 items-center text-sm hover:bg-gray-50"
              >
                <div>{index + 1}</div>
                <div>{item.referralId}</div>
                <div className="flex items-center gap-2">
                  <img
                    src={item.referralBy.avatar}
                    alt="referral by avatar"
                    className="w-10 h-10 rounded-full border border-blue-500  p-0.5"
                  />
                  <span>{item.referralBy.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <img
                    src={item.referredMember.avatar}
                    alt="referred member avatar"
                    className="w-10 h-10 rounded-full border border-blue-500  p-0.5"
                  />
                  <span>{item.referredMember.name}</span>
                </div>
                <div>{item.email}</div>
                <div>{item.signUpDate}</div>
                <div
                  className={`font-medium ${
                    item.status === "Active" ? "text-green-600" : "text-gray-500"
                  }`}
                >
                  {item.status}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-gray-500 col-span-7">
              No referrals found.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UniqueReferral;
