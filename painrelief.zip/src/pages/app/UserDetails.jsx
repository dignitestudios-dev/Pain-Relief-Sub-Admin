import { useState } from "react";
import { medical } from "../../assets/export";
import ReferredFriends from "../../components/app/ReferredFriends";

const provider = {
  name: "John Alex",
  email: "john.alex@gmail.com",
  avatar: "https://i.pravatar.cc/100?img=5",
  clinicTitle: "Clinic Title",
  clinicEmail: "clinic@gmail.com",
  phone: "+000 0000 000",
  location: "Dallas, TX – 802 PainEase Plaza\nMassage Therapy Care",
  reliefCoach: "Authorized Pain Relief Coach",
  npi: "Lorem Ipsum Dolor at",
  website: "www.website.com",
  description:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...",
};

// Simulated medical license images
const medicalLicenses = [
  {
    id: 1,
    title: "Medical License",
    image: medical,
  },
  {
    id: 2,
    title: "Medical License",
    image: medical,
  },
  {
    id: 3,
    title: "Medical License",
    image: medical,
  },
  {
    id: 4,
    title: "Medical License",
    image: medical,
  },
];


const UserDetails = () => {
  const [activeTab, setActiveTab] = useState("Basic Info");

  return (
    <div className="p-6 bg-white rounded-lg shadow mx-auto">
      {/* Title */}
      <h2 className="text-[24px] font-bold mb-4">Service Provider Details</h2>

      {/* Header */}
      <div className="flex items-center bg-[#FAFAFA] rounded-lg p-6 shadow-sm mb-4">
        <img
          src={provider.avatar}
          alt="avatar"
          className="w-20 h-20 rounded-full border border-blue-500 mr-6 p-0.5"
        />
        <div>
          <h3 className="text-xl font-semibold">{provider.name}</h3>
          <p className="text-gray-500">{provider.email}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 rounded-md shadow p-2 mb-6">
        {["Basic Info", "Medical License", "Referral Friends"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-8 py-2 rounded-md ${
              activeTab === tab
                ? "bg-gradient-to-bl from-[#29ABE2] to-[#63CFAC] text-white font-semibold"
                : "text-gray-600"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab Content: Basic Info */}
      {activeTab === "Basic Info" && (
        <div className="bg-[#FAFAFA] p-6 rounded-md text-sm space-y-6">
          <p className="text-[24px]">Clinic Profile</p>
          <span className="w-full border border-b flex"></span>
          <InfoRow label="Name of Clinic/Practice" value={provider.clinicTitle} />
          <InfoRow label="Email Address" value={provider.clinicEmail} />
          <InfoRow label="Mobile Number" value={provider.phone} />
          <InfoRow label="Clinic Location" value={provider.location} multi />
          <InfoRow label="Pain Relief Coach" value={provider.reliefCoach} />
          <InfoRow label="Provider Individual NPI" value={provider.npi} />
          <InfoRow label="Website" value={provider.website} />
          <div>
            <p className="font-medium mb-1">Description</p>
            <p className="text-gray-600 whitespace-pre-line">{provider.description}</p>
          </div>
        </div>
      )}

      {/* Tab Content: Medical License (images in 4-column grid) */}
      {activeTab === "Medical License" && (
        <div className="p-6 bg-[#FAFAFA] rounded-md">
          <h3 className="text-2xl font-semibold mb-6 text-black">Chiropractor Details</h3>
          <span className="w-full border border-b flex mb-6"></span>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {medicalLicenses.map((license) => (
              <div
                key={license.id}
                className="rounded-md overflow-hidden"
              >
                 <div className="p-3 text-left font-medium text-black">
                  {license.title}
                </div>
                <img
                  src={license.image}
                  alt={license.title}
                  className="w-full h-40 object-cover"
                />
                
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Placeholder for Referral Friends */}
      {activeTab === "Referral Friends" && <ReferredFriends />}

    </div>
  );
};

const InfoRow = ({ label, value, multi, last }) => (
  <div className={`py-2 ${!last ? "border-b border-gray-300" : ""}`}>
    <p className="text-gray-400 mb-1">{label}</p>
    <p className={`text-black ${multi ? "whitespace-pre-line" : ""}`}>{value}</p>
  </div>
);

export default UserDetails;
