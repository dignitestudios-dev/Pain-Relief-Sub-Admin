import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router";
import { RiMenuLine, RiCloseLine } from "react-icons/ri";
import { IoLogOutOutline } from "react-icons/io5";
import Cookies from "js-cookie";
import { sidebarData } from "../../static/Sidebar";
import { Logo } from "../../assets/export";

// Import images
// import { link, link2, linkActive, link2Active } from "../assets/export"; 

const Sidebar = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [activeLink, setActiveLink] = useState(null);
  const navigate = useNavigate();

  const toggleDrawer = () => setIsDrawerOpen(!isDrawerOpen);
  const handleLinkClick = (url) => setActiveLink(url);
  const handleLogout = () => {
    Cookies.remove("authToken");
    navigate("/auth/login");
  };

  return (
    <div>
      {/* Mobile toggle button */}
      <button
        onClick={toggleDrawer}
        className="lg:hidden fixed top-4 left-4 z-50 text-black"
      >
        {isDrawerOpen ? <RiCloseLine size={24} /> : <RiMenuLine size={24} />}
      </button>

      {/* Sidebar */}
      <div
        className={`fixed lg:static ml-4 mt-4 mb-4 rounded-lg top-0 left-0 w-[270px] border shadow-lg bg-white py-4 flex flex-col transition-transform duration-300
          ${isDrawerOpen ? "translate-x-0" : "-translate-x-full"}
          lg:translate-x-0 z-40 min-h-[calc(100vh-2rem)] overflow-hidden`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 pl-6">
          <img src={Logo} alt="logo" className="h-[65px] w-[65px]" />
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-gray-800">Pain Relief USA</span>
            <span className="text-xs text-gray-500">Pain Relief Made Easy</span>
          </div>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 mt-6 px-2 overflow-y-auto scrollbar-hide pb-6">
          <ul className="space-y-4">
            {sidebarData?.map((sidebar, index) => (
              <li key={index} className="flex items-center">
                <NavLink
                  to={sidebar.url}
                  onClick={() => handleLinkClick(sidebar.url)}
                  className={`flex items-center w-[98%] gap-2 px-4 py-3 rounded-xl transition-all ${
                    activeLink === sidebar.url
                      ? "bg-gradient-to-l from-[#29ABE2] to-[#63CFAC] text-white"
                      : "text-black hover:bg-gradient-to-l from-[#29ABE2] to-[#63CFAC] hover:text-white"
                  }`}
                >
                  {/* Conditionally render the icon */}
                  <span className="text-xl">
                    <img
                      src={activeLink === sidebar.url ? sidebar.activeIcon : sidebar.icon}
                      alt={`${sidebar.title} Icon`}
                      className="w-5 h-5"
                    />
                  </span>
                  <span className="text-[11px] font-medium">{sidebar.title}</span>
                </NavLink>
              </li>
            ))}

            {/* Logout */}
            <li className="ml-2 mt-8">
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 px-6 py-3 w-full rounded-2xl text-black hover:bg-gray-100"
              >
                <IoLogOutOutline size={20} />
                <span className="text-[11px] font-medium">Logout</span>
              </button>
            </li>
          </ul>
        </div>
      </div>

      {/* Mobile overlay */}
      {isDrawerOpen && (
        <div
          onClick={toggleDrawer}
          className="fixed inset-0 bg-black opacity-50 lg:hidden z-30"
        />
      )}
    </div>
  );
};

export default Sidebar;
