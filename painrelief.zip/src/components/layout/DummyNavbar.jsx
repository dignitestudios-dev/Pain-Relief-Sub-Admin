import { Logo } from "../../assets/export";

const DummyNavbar = () => {
  const username = "John Doe"; // example username
  const userAvatar = "https://i.pravatar.cc/40"; // example avatar URL

  return (
    <div className="w-full px-4 py-8 flex justify-end items-center gap-3">
      <span className="text-white font-medium">{username}</span>
      <img
        src={userAvatar}
        alt="user-avatar"
        className="w-14 h-14 rounded-full object-cover border border-blue-500  p-0.5"
      />
    </div>
  );
};

export default DummyNavbar;


