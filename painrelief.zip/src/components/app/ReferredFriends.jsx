import { useState } from "react";

const staticUsers = [
  {
    id: 1,
    referralId: "REF123456",
    name: "Alice Johnson",
    email: "alice@example.com",
    signupDate: "2025-06-05T14:19:58.884Z",
    status: "pending",
    avatar: "https://i.pravatar.cc/40?img=1",
  },
  {
    id: 2,
    referralId: "REF654321",
    name: "Bob Smith",
    email: "bob@example.com",
    signupDate: "2025-06-01T10:00:00.000Z",
    status: "approved",
    avatar: "https://i.pravatar.cc/40?img=2",
  },
  {
    id: 3,
    referralId: "REF998877",
    name: "Carla Davis",
    email: "carla@example.com",
    signupDate: "2025-06-03T18:30:00.000Z",
    status: "pending",
    avatar: "https://i.pravatar.cc/40?img=3",
  },
];

const capitalizeFirstLetter = (text) => {
  if (!text) return "";
  return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
};

const ReferredFriends = () => {
  const [search, setSearch] = useState("");

  const filteredData = staticUsers.filter((user) =>
    user.name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 bg-[#FAFAFA] rounded-lg shadow">
      {/* Header */}
      <div className="flex justify-between items-center mb-4 border-b pb-4">
        <h2 className="text-[32px] font-bold">Referred Friends</h2>
        <p className="text-blue-500 border-b border-blue-500">Download Brochure/QR Code</p>
      </div>

      {/* Table */}
      <div className="bg-[#FAFAFA] p-4 rounded-md">
        {/* Column headers */}
        <div
          className="grid grid-cols-[40px_1.2fr_1.5fr_1.5fr_1.3fr_1fr] gap-4 px-4 py-3 text-sm font-semibold text-black"
          style={{
            background: "linear-gradient(90deg, rgba(150,210,240,1) 0%, rgba(190,230,210,1) 50%)",
          }}
        >
          <div>#</div>
          <div>Referral ID</div>
          <div>Referred Member</div>
          <div>Referred Email</div>
          <div>Signup Date</div>
          <div>Status</div>
        </div>

        {/* Rows */}
        <div className="divide-y">
          {filteredData.length > 0 ? (
            filteredData.map((user, index) => (
              <div
                key={user.id}
                className="grid grid-cols-[40px_1.2fr_1.5fr_1.5fr_1.3fr_1fr] gap-4 px-4 py-6 items-center text-sm hover:bg-gray-50"
              >
                <div>{index + 1}</div>
                <div>{user.referralId}</div>
                <div className="flex items-center gap-2">
                  <img
                    src={user.avatar}
                    alt="avatar"
                    className="w-10 h-10 rounded-full"
                  />
                  <span>{user.name}</span>
                </div>
                <div>{user.email}</div>
                <div>
                  {new Date(user.signupDate).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                  })}
                </div>
                <div>{capitalizeFirstLetter(user.status)}</div>
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-gray-500 col-span-6">
              No results found.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReferredFriends;
