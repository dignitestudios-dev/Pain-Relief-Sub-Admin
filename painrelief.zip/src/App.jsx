import { Route, Routes } from "react-router";
import "./App.css";
import DashboardLayout from "./layouts/DashboardLayout";
import DummyHome from "./pages/app/DummyHome";
import DummyLogin from "./pages/authentication/DummyLogin";
import AuthLayout from "./layouts/AuthLayout";
import UniqueReferral from "./pages/app/UniqueReferral";
import UserDetails from "./pages/app/UserDetails";
import Profile from "./pages/app/Profile";
import Login from "./pages/app/Login";
import ForgotPassword from "./pages/app/ForgotPassword";
import VerifyOtp from "./pages/app/VerifyOtp";

function App() {
  return (
    <Routes>
      <Route
        path="/"
        element={
          <div className="text-7xl">
            Project Template || Please read readme file
          </div>
        }
      />

      <Route path="app" element={<DashboardLayout />}>
        <Route path="dashboard" element={<DummyHome />} />
      </Route>

      <Route path="app" element={<DashboardLayout />}>
        <Route path="unique-referral" element={<UniqueReferral />} />
      </Route>

  <Route path="app" element={<DashboardLayout />}>
        <Route path="user-details" element={<UserDetails />} />
      </Route>

       <Route path="app" element={<DashboardLayout />}>
        <Route path="profile" element={<Profile />} />
      </Route>

      <Route path="auth" element={<AuthLayout />}>
        <Route path="login" element={<Login />} />
      </Route>

       <Route path="auth" element={<AuthLayout />}>
        <Route path="forgot-password" element={<ForgotPassword />} />
      </Route>

      <Route path="auth" element={<AuthLayout />}>
        <Route path="verify-otp" element={<VerifyOtp />} />
      </Route>

      <Route
        path="*"
        element={<div className="text-7xl">Page Not Found</div>}
      />
    </Routes>
  );
}

export default App;
